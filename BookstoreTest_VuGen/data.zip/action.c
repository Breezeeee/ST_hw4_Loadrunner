Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("success.txt", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	lr_think_time(4);

	web_url("adu.gif", 
		"URL=http://adu.g-fox.cn/adu.gif?channelid=stub.firefox.com.cn&fxversion=67.0.1&ceversion=2019.5&ver=2_2&pk=%7B3cb3755e-57ca-40f3-b991-89fc78f0b519%7D&uk=%7Bc4f76ad7-cf4f-4d87-905a-e32fa1f6c70c%7D&cehome=true&locale=zh-CN&age=0&default=false&defaultHttp=false&flash=&tracking=2&now=1559756362733", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("101.200.120.41:12306", 
		"URL=http://101.200.120.41:12306/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/login/check_session", ENDITEM, 
		"Url=/static/media/csapp.353e1ee5.png", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(9);

	web_submit_data("check", 
		"Action=http://101.200.120.41:12306/login/check", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/login", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=usn", "Value=1", ENDITEM, 
		"Name=psw", "Value=1234abcd", ENDITEM, 
		EXTRARES, 
		"Url=check_session", "Referer=http://101.200.120.41:12306/booklist", ENDITEM, 
		LAST);

	web_custom_request("getBook", 
		"URL=http://101.200.120.41:12306/getBook", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/booklist", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/login/check_session", "Referer=http://101.200.120.41:12306/purchase", ENDITEM, 
		LAST);

	web_custom_request("getBook_2", 
		"URL=http://101.200.120.41:12306/getBook", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/purchase", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("get_comment", 
		"Action=http://101.200.120.41:12306/purchase/get_comment", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/purchase", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=bookID", "Value=2", ENDITEM, 
		LAST);

	web_submit_data("add_to_cart", 
		"Action=http://101.200.120.41:12306/purchase/add_to_cart", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/purchase", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=book_id", "Value=2", ENDITEM, 
		EXTRARES, 
		"Url=../login/check_session", "Referer=http://101.200.120.41:12306/booklist", ENDITEM, 
		LAST);

	web_custom_request("getBook_3", 
		"URL=http://101.200.120.41:12306/getBook", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/booklist", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=/login/check_session", "Referer=http://101.200.120.41:12306/purchase", ENDITEM, 
		LAST);

	web_custom_request("getBook_4", 
		"URL=http://101.200.120.41:12306/getBook", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/purchase", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("get_comment_2", 
		"Action=http://101.200.120.41:12306/purchase/get_comment", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/purchase", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=bookID", "Value=3", ENDITEM, 
		LAST);

	web_submit_data("add_to_cart_2", 
		"Action=http://101.200.120.41:12306/purchase/add_to_cart", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/purchase", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=book_id", "Value=3", ENDITEM, 
		EXTRARES, 
		"Url=../login/check_session", "Referer=http://101.200.120.41:12306/cart", ENDITEM, 
		LAST);

	web_custom_request("fetch_cart", 
		"URL=http://101.200.120.41:12306/purchase/fetch_cart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/cart", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_think_time(4);

	web_custom_request("create_indent", 
		"URL=http://101.200.120.41:12306/purchase/create_indent", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/cart", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../login/check_session", "Referer=http://101.200.120.41:12306/indents", ENDITEM, 
		LAST);

	web_submit_data("fetch_indents", 
		"Action=http://101.200.120.41:12306/fetch_indents", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/indents", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=book_filter", "Value=", ENDITEM, 
		"Name=author_filter", "Value=", ENDITEM, 
		"Name=time_filter", "Value=", ENDITEM, 
		EXTRARES, 
		"Url=/login/check_session", "Referer=http://101.200.120.41:12306/profile", ENDITEM, 
		LAST);

	web_custom_request("getinfo", 
		"URL=http://101.200.120.41:12306/profile/getinfo", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://101.200.120.41:12306/profile", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("logout", 
		"URL=http://101.200.120.41:12306/login/logout", 
		"Resource=0", 
		"Referer=http://101.200.120.41:12306/profile", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}